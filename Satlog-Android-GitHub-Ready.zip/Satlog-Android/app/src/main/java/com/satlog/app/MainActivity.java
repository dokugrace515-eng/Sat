package com.satlog.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int gold = Color.rgb(212,175,55), green = Color.rgb(0,200,83), dark = Color.rgb(9,9,9);
    TextView text(String s, int sp, int color, boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); v.setPadding(24,18,24,18);
        if(bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return v;
    }
    Button button(String s) {
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setBackgroundColor(green);
        b.setOnClickListener(v -> Toast.makeText(this, s+" — prototype", Toast.LENGTH_SHORT).show()); return b;
    }
    @Override public void onCreate(Bundle b) { super.onCreate(b);
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(dark);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,28);
        TextView logo=text("SATLOG",32,gold,true); logo.setGravity(Gravity.CENTER); root.addView(logo);
        TextView sub=text("SPORTS • ODDS • BET SLIP",13,Color.LTGRAY,false); sub.setGravity(Gravity.CENTER); root.addView(sub);
        root.addView(text("Featured Matches",22,Color.WHITE,true));
        String[] games={"Premier League\nHome  2.10     Draw  3.25     Away  3.40","Champions League\nHome  1.85     Draw  3.60     Away  4.10","La Liga\nHome  2.45     Draw  3.10     Away  2.90"};
        for(String g:games){ TextView card=text(g,17,Color.WHITE,false); card.setBackgroundColor(Color.rgb(28,28,28)); card.setPadding(30,28,30,28); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,10,0,10); root.addView(card,p); }
        root.addView(text("Quick Actions",22,gold,true)); root.addView(button("Open Bet Slip")); root.addView(button("My Bets"));
        TextView note=text("Prototype only — sample odds and matches. No real-money betting or payments are connected.",13,Color.GRAY,false); note.setGravity(Gravity.CENTER); root.addView(note);
        scroll.addView(root); setContentView(scroll);
    }
}
