# Satlog Android Prototype
Native Android prototype with a gold/dark/green interface.

## Build
Open this folder in Android Studio and build an APK, or upload the repository to a compatible Android/Gradle cloud build service.

This prototype uses sample matches/odds only. It does not process real-money bets or payments.

## Build APK with GitHub Actions
1. Upload the contents of this project to a GitHub repository.
2. Open the repository's Actions tab.
3. Select **Build Satlog APK** and run the workflow (or push to main/master).
4. When the workflow finishes, open the run and download the **Satlog-debug-apk** artifact.
5. Extract it to get `app-debug.apk`, then install it on your Android phone.
